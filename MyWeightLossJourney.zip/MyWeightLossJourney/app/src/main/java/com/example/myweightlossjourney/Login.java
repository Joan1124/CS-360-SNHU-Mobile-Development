package com.example.myweightlossjourney;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

import java.lang.reflect.Constructor;

public class Login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        TextView username = (TextView) findViewById(R.id.username);
        TextView password = (TextView) findViewById(R.id.password);

        String userQuery = username.getText().toString();
        String passwordQuery = password.getText().toString();

        DBHandler db = new DBHandler(Login.this);


        Button loginbtn = (Button) findViewById(R.id.login);




       configureLoginButton(userQuery, passwordQuery);
       configureRegisterButton();

    }



    private void configureRegisterButton() {
        Button register = (Button) findViewById(R.id.createAccount);
        register.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                startActivity(new Intent(Login.this, Register.class));
            }
        });

}

    private void configureLoginButton(String username, String password) {
        Button login = (Button) findViewById(R.id.login);
        DBHandler db = new DBHandler(Login.this);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                String dbUsername = db.getData(username,password);
//                boolean data = db.getUsername(username);
                Toast.makeText(Login.this, "Login Succesful", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(Login.this, MainActivity.class));



//                    startActivity(new Intent(Login.this, MainActivity.class));

            }
        });
    }


}






