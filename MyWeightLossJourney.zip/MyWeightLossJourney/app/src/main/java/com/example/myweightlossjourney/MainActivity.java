package com.example.myweightlossjourney;


import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.androidplot.xy.LineAndPointFormatter;
import com.androidplot.xy.PanZoom;
import com.androidplot.xy.SimpleXYSeries;
import com.androidplot.xy.XYPlot;
import com.androidplot.xy.XYSeries;

import java.util.Arrays;

public class MainActivity extends AppCompatActivity {
    private XYPlot myPlot;
    Button button;
    Toolbar myToolBar;
    private Object Menu;



    @Override
    public boolean onCreateOptionsMenu(android.view.Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);


    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
        getSupportActionBar().setTitle("My Weight Loss Journey");


        myPlot = findViewById(R.id.xyplot);
        Number[] series1Number = {1, 5, 4, 2, 6, 10, 8, 5, 14, 7};
        XYSeries series1 = new SimpleXYSeries(Arrays.asList(series1Number), SimpleXYSeries.ArrayFormat.Y_VALS_ONLY, "Units: lbs");

        LineAndPointFormatter series1Format = new LineAndPointFormatter(Color.BLACK, Color.GREEN,null, null);

        myPlot.addSeries(series1, series1Format);
        series1Format.getLinePaint().setStrokeWidth(10f);
        series1Format.getVertexPaint().setStrokeWidth(30f);

        PanZoom.attach(myPlot);

        configureAddWeightButton();
    }

    private void configureAddWeightButton() {
        Button register = (Button) findViewById(R.id.addWeightEntry);
        register.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                startActivity(new Intent(MainActivity.this, addWeight.class));
            }
        });

    }


}