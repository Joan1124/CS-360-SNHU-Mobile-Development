package com.example.myweightlossjourney;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.Date;

public class DBHandler extends SQLiteOpenHelper {

    String cursorUsername;
    String cursorPassword;
    // creating a constant variables for our database.
    // below variable is for our database name.
    private static final String DB_NAME = "MyWeightLossJourneyDB";

    // below int is our database version
    private static final int DB_VERSION = 1;

    // below variable is for our table name.
    private static final String TABLE_NAME = "users";

    // below variable is for our id column.
    private static final String ID_COL = "id";

    // below variable is for our course name column
    private static final String USERNAME_COL = "username";

    // below variable id for our course duration column.
    private static final String PASSWORD_COL = "password";

    // below variable for our course description column.
    private static final String EMAIL_COL = "email";

    //TABLE 2
    private static final String TABLE_NAME2 = "weightData";
    //Variable for weight info
    private static final String WEIGHT_COL = "weight";
    //VAriable for date of entry
    private static final String DATE_COL = "date";

    private static final String USER_id = "user_id";


    public DBHandler(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }
    // below method is for creating a database by running a sqlite query
    @Override
    public void onCreate(SQLiteDatabase db) {
        // on below line we are creating
        // an sqlite query and we are
        // setting our column names
        // along with their data types.
        String query = "CREATE TABLE " + TABLE_NAME + " ("
                + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + USERNAME_COL + " TEXT,"
                + PASSWORD_COL + " TEXT,"
                + EMAIL_COL + " TEXT)";

        String query2 = "CREATE TABLE " + TABLE_NAME2 + " ("
                +ID_COL + "INTEGER PRIMARY KEY AUTOINCREMENT, "
                +USER_id + "INTEGER NOT NULL,"
                +WEIGHT_COL + "INTEGER,"
                +DATE_COL + "TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,"
                +"FOREIGN KEY (USER_id) REFERENCES users(id))";
        // at last we are calling a exec sql
        // method to execute above sql query
        db.execSQL(query);
        db.execSQL(query2);
    }

    // this method is use to add new course to our sqlite database.
    public void addNewUser(String courseName, String password, String email) {

        // on below line we are creating a variable for
        // our sqlite database and calling writable method
        // as we are writing data in our database.
        SQLiteDatabase db = this.getWritableDatabase();

        // on below line we are creating a
        // variable for content values.
        ContentValues values = new ContentValues();

        // on below line we are passing all values
        // along with its key and value pair.
        values.put(USERNAME_COL, courseName);
        values.put(PASSWORD_COL, password);
        values.put(EMAIL_COL, email);


        // after adding all values we are passing
        // content values to our table.
        db.insert(TABLE_NAME, null, values);

        // at last we are closing our
        // database after adding database.
        db.close();
    }



//    public boolean getData(String user, String password){
//        SQLiteDatabase db = this.getReadableDatabase();
//        String[] columns = {DBHandler.USERNAME_COL, DBHandler.PASSWORD_COL};
////        Cursor cursor = db.rawQuery("Select * from "+ TABLE_NAME +" where " + USERNAME_COL +"=?" + " and " + PASSWORD_COL + "=?", new String[]{user,password});
//        Cursor cursor= db.query(DBHandler.TABLE_NAME, columns, DBHandler.USERNAME_COL+" = '" + user + "'",null,null,null,null);
//        StringBuffer buffer = new StringBuffer();
//        while (cursor.moveToNext()){
//            int index1=cursor.getColumnIndex(DBHandler.USERNAME_COL);
//            int index2=cursor.getColumnIndex(DBHandler.PASSWORD_COL);
//            cursorUsername = cursor.getString(index1);
//            cursorPassword = cursor.getString(index2);
//        }
//        if (cursorUsername == user){
//            return true;
//
//        }
//        else {
//            return false;
//        }
//    }


//    public boolean getUsername(String user){
//        SQLiteDatabase db = this.getReadableDatabase();
//        String[] columns = {DBHandler.USERNAME_COL};
//        Cursor cursor = db.rawQuery("Select * from "+ TABLE_NAME +" where " + USERNAME_COL +"=?", new String[]{user});
//        if (cursor.getCount() > 0){
//            return true;
//        }
//        else{
//            return false;
//        }
//        StringBuffer buffer2 = new StringBuffer();
//        while (cursor.moveToNext()){
//            int index1=cursor.getColumnIndex(DBHandler.USERNAME_COL);
//            String cursorUsername = cursor.getString(index1);
//            buffer2.append(cursorUsername);
//        }
//        cursor.close();
//
//        return buffer2.toString();
//    }

//    public String getPassword(String password){
//        SQLiteDatabase db = this.getReadableDatabase();
//        String[] columns = {DBHandler.PASSWORD_COL};
//        Cursor cursor= db.query(DBHandler.TABLE_NAME, columns, DBHandler.PASSWORD_COL+" = '" + password + "'",null,null,null,null);
//        StringBuffer buffer = new StringBuffer();
//        while (cursor.moveToNext()){
//            int index1=cursor.getColumnIndex(DBHandler.PASSWORD_COL);
//            String cursorPassword = cursor.getString(index1);
//            buffer.append(cursorPassword);
//        }
//        cursor.close();
//        return buffer.toString();
//    }
//



//
    // this method is use to add new course to our sqlite database.
    public void addNewWeightEntry(int weight,String date) {

        // on below line we are creating a variable for
        // our sqlite database and calling writable method
        // as we are writing data in our database.
        SQLiteDatabase db = this.getWritableDatabase();

        // on below line we are creating a
        // variable for content values.
        ContentValues values = new ContentValues();

        // on below line we are passing all values
        // along with its key and value pair.

        values.put(WEIGHT_COL, weight);
        values.put(DATE_COL,date);

        // after adding all values we are passing
        // content values to our table.
        db.insert(TABLE_NAME2, null, values);

        // at last we are closing our
        // database after adding database.
        db.close();
    }




    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // this method is called to check if the table exists already.
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME2);
        onCreate(db);
    }

}