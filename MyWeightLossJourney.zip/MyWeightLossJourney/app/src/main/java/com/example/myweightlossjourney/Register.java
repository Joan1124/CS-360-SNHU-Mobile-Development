package com.example.myweightlossjourney;


import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

import java.util.Date;

public class Register extends AppCompatActivity {

    private EditText usernameEdt;
    private EditText emailEdt;
    private EditText passwordEdt;


    private DBHandler dbHandler;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        usernameEdt = findViewById(R.id.inputUsername);
        passwordEdt= findViewById(R.id.inputPassword);
        emailEdt = findViewById(R.id.inputEmail);



        Button regbtn = (Button) findViewById(R.id.btnRegister);

        dbHandler = new DBHandler(Register.this);

        regbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // below line is to get data from all edit text fields.
                String username = usernameEdt.getText().toString();
                String password = passwordEdt.getText().toString();
                String email = emailEdt.getText().toString();


                // validating if the text fields are empty or not.
                if (username.isEmpty() && password.isEmpty() && email.isEmpty() ) {
                    Toast.makeText(Register.this, "Please enter all the data..", Toast.LENGTH_SHORT).show();
                    return;
                }

                // on below line we are calling a method to add new
                // course to sqlite data and pass all our values to it.
                dbHandler.addNewUser(username, password, email);

                // after adding the data we are displaying a toast message.
                Toast.makeText(Register.this, " Registration succesful", Toast.LENGTH_SHORT).show();
                usernameEdt.setText("");
                emailEdt.setText("");
                passwordEdt.setText("");
            }
        });








    }









}


