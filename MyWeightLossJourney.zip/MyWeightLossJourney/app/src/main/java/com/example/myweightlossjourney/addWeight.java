package com.example.myweightlossjourney;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Date;

public class addWeight extends AppCompatActivity {

    private EditText weightEDT;

    private DBHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_weight);


        weightEDT = findViewById(R.id.inputCurrentWeight);


        Button regbtn = (Button) findViewById(R.id.EnterWeight);

        dbHandler = new DBHandler(addWeight.this);

        regbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // below line is to get data from all edit text fields.
                String value = weightEDT.getText().toString();
                int weight = Integer.parseInt(value);


                // validating if the text fields are empty or not.
                if (value.isEmpty()) {
                    Toast.makeText(addWeight.this, "Please enter your weight", Toast.LENGTH_SHORT).show();
                    return;
                }

                String date = new Date().toString();
                // on below line we are calling a method to add new
                // course to sqlite data and pass all our values to it.
                dbHandler.addNewWeightEntry(weight,date);

                // after adding the data we are displaying a toast message.
                Toast.makeText(addWeight.this, "Entry added.", Toast.LENGTH_SHORT).show();
                weightEDT.setText("");

            }
        });
    }
}